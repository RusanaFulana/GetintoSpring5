package com.example.demo.utils;

public class ArrayUtil {

    public static String[] array(String... args) {
        return args;
    }
}
