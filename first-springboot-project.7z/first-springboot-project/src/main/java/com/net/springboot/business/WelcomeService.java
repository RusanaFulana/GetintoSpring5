package com.net.springboot.business;

import org.springframework.stereotype.Component;

//Spring to manage bean and create instance for this
@Component
public class WelcomeService {
	public String welcomemessage() {
		 return "Good morning friend and welcome to house for dinner";
	 }
}
