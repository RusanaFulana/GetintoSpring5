package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;

@Service
public class StudentService {
	
	@Autowired
	StudentRepository studRepo;
	
	//Create operation
	public Student create(String firstName, String lastName, int age) {
		return studRepo.save(new Student(firstName,lastName,age));
	}
	
	//retreieve operation
	public List<Student> getAll(){
		return studRepo.findAll();
	}
	public Student getByFirstName(String firstName) {
		return studRepo.findByFirstName(firstName);
	}
	//update Operation
	
	public Student update(String firstName, String lastName, int age) {
		Student st = studRepo.findByFirstName(firstName);
			st.setAge(10);
			return studRepo.save(st);
	}
	
	//delete operation
	
	public void deleteAll() {
		studRepo.deleteAll();
	}
	
	public void delete(String firstName) {
		Student st = studRepo.findByFirstName(firstName);
		 studRepo.delete(st);
	}
}
