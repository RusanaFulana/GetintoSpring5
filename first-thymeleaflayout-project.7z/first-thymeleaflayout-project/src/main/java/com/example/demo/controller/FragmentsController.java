package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.demo.utils.StudentUtils;

@Controller
public class FragmentsController {

    @GetMapping("/fragments")
    public String getHome() {
        return "views/fragments.html";
    }

    @GetMapping("/markup")
    public String markupPage() {
        return "views/markup.html";
    }

    @GetMapping("/params")
    public String paramsPage() {
        return "views/params.html";
    }

    @GetMapping("/other")
    public String otherPage(Model model) {
        model.addAttribute("data", StudentUtils.buildStudents());
        return "views/other.html";
    }

}
