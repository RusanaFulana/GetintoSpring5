package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstRestwebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstRestwebServiceApplication.class, args);
	}

}
