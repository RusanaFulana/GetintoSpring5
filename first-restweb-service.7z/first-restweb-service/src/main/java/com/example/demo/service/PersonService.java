package com.example.demo.service;

import java.util.Hashtable;
import com.example.demo.model.Person;
import org.springframework.stereotype.Service;

@Service
public class PersonService {
	Hashtable<String, Person> persons = new Hashtable<String, Person>();
	
	public PersonService() {
		Person p = new Person();
		p.setId("1");
		p.setFirstname("Mamta");
		p.setLastname("kaper");
		p.setAge(34);
		persons.put("1",p);
		
		p = new Person();
		p.setId("2");
		p.setFirstname("Lachan");
		p.setLastname("kaper");
		p.setAge(36);
		persons.put("2",p);
		
		p = new Person();
		p.setId("3");
		p.setFirstname("Mayank");
		p.setLastname("kaper");
		p.setAge(9);
		persons.put("3",p);
		
		p = new Person();
		p.setId("4");
		p.setFirstname("Laksh");
		p.setLastname("kaper");
		p.setAge(4);
		persons.put("4",p);
	}
	
	public Person getPerson(String id) {
		if(persons.containsKey(id)) {
			return persons.get(id);
		} else {
			return null;
		}
	}
	
	public Hashtable<String, Person> getAll(){
		return persons;
	}
}
