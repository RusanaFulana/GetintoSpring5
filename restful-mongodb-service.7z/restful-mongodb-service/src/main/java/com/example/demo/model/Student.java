package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Student {
	@Id
	String id;
	String firstName;
	String lastName;
	int age;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Student(String firsName, String lasName, int age) {
		this.firstName = firsName;
		this.lastName = lasName;
		this.age = age;
	}
	
	public String toString() {
		return "firstName: "+firstName+"lastName"+lastName+"age"+age;
	}
}
