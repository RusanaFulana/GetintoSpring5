package com.net.springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.net.springboot.business.WelcomeService;

@RestController
public class WelcomeController {
	
	//Dependency
	//private WelcomeService service = new WelcomeService();
	//injected here - autowiring
	@Autowired
	private WelcomeService service;
	
	@RequestMapping("/welcome")
	public String welcome() {
		return service.welcomemessage();
	}
	
//Spring to manage bean and create instance for this
/*@Component
 class WelcomeService {
	 
	 public String welcomemessage() {
		 return "Good morning friend and welcome to house";
	 }
 }*/
}
