var count = [[${students.size()}]];
alert("Number of students in group: " + count);