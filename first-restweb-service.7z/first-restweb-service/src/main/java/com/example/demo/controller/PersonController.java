package com.example.demo.controller;

import java.util.Hashtable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.PersonService;
import com.example.demo.model.Person;

@RestController
@RequestMapping("/persons")
public class PersonController {
	
	@Autowired
	PersonService serv;
	
	@RequestMapping("/all")
	public Hashtable<String, Person> getAll(){
		return serv.getAll();
	}
	
	@RequestMapping("{id}")
	public Person getPerson(@PathVariable("id") String id) {
		return serv.getPerson(id);
	}
}
