package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Student;
import com.example.demo.service.StudentService;

@RestController
public class StudentController {
	
	@Autowired
	private StudentService studServ;

	@RequestMapping("/create")
	public String create(@RequestParam String firstName, @RequestParam String lastName, @RequestParam int age) {
		Student st = studServ.create(firstName, lastName, age);
		return st.toString();
	}
	
	@RequestMapping("/get")
	public Student getStudent(@RequestParam String firsName) {
		return studServ.getByFirstName(firsName);
	}
}
